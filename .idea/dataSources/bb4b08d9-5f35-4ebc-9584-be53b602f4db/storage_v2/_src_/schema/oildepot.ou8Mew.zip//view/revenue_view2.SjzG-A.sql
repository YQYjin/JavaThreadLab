create definer = root@localhost view revenue_view2 as
select `oildepot`.`revenues_view`.`油品编号` AS `油品编号`,
       `oildepot`.`revenues_view`.`油品名称` AS `油品名称`,
       `oildepot`.`revenues_view`.`净利润`   AS `净利润`
from `oildepot`.`revenues_view`
where (`oildepot`.`revenues_view`.`净利润` > 1000000);

-- comment on column revenue_view2.油品编号 not supported: 油品编号

-- comment on column revenue_view2.油品名称 not supported: 油品名称

