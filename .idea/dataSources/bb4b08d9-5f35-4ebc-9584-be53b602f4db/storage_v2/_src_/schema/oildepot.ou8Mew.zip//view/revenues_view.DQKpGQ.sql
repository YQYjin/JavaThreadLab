create definer = root@localhost view revenues_view as
select `oildepot`.`oil`.`ID` AS `油品编号`, `oildepot`.`oil`.`Name` AS `油品名称`, (`a`.`asum` - `b`.`bsum`) AS `净利润`
from (((select `oildepot`.`sell`.`ID`                                                                            AS `ID`,
               sum(((`oildepot`.`sell`.`Purchases` * `oildepot`.`sell`.`Price`) *
                    `oildepot`.`sell`.`Discount`))                                                               AS `asum`
        from (`oildepot`.`sell` join `oildepot`.`oil` on ((`oildepot`.`sell`.`ID` = `oildepot`.`oil`.`ID`)))
        where (`oildepot`.`sell`.`Time` like '2023%')
        group by `oildepot`.`sell`.`ID`) `a` left join (select `oildepot`.`stock`.`ID`                                            AS `ID`,
                                                               sum((`oildepot`.`stock`.`Purchases` * `oildepot`.`stock`.`Price`)) AS `bsum`
                                                        from (`oildepot`.`stock` join `oildepot`.`oil`
                                                              on ((`oildepot`.`stock`.`ID` = `oildepot`.`oil`.`ID`)))
                                                        where (`oildepot`.`stock`.`Time` like '2023%')
                                                        group by `oildepot`.`oil`.`ID`) `b`
       on ((`a`.`ID` = `b`.`ID`))) join `oildepot`.`oil` on ((`a`.`ID` = `oildepot`.`oil`.`ID`)))
order by (`a`.`asum` - `b`.`bsum`) desc;

-- comment on column revenues_view.油品编号 not supported: 油品编号

-- comment on column revenues_view.油品名称 not supported: 油品名称

